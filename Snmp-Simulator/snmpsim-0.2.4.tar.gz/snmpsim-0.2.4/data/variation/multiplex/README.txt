This directory is an example repository of .snmprec files that can
be used by the "multiplex" variation module for the purpose of building SNMP
responses choosing one of these snmprec files in a time-dependent fashion.

Such .snmprec files can be created automatically by the snmprec.py tool.

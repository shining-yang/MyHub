# http://www.python.org/dev/peps/pep-0396/
__version__ = '0.2.4'
